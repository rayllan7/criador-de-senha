const numeroSenha= document.queryselector('parametro-senha_textDoco')
